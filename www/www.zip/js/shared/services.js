angular.module('starter').factory('CategoryService', function($http,serverConfig){
    return {
        getAll : function() {
            return $http({
                method: 'GET',
                url: serverConfig.address+'api/category'
            });
        }
    }
});